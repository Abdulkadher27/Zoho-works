#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

typedef struct {
    int a;
    int b;
    int result;
} ThreadArgs;

void* add_ab_thread(void* args) {
    ThreadArgs* data = (ThreadArgs*)args;
    data->result = data->a + data->b;
    pthread_exit(NULL);
}

void* add_cd_thread(void* args) {
    ThreadArgs* data = (ThreadArgs*)args;
    data->result = data->a + data->b;
    pthread_exit(NULL);
}

void* add_ef_thread(void* args) {
    ThreadArgs* data = (ThreadArgs*)args;
    data->result = data->a + data->b;
    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2, thread3;
    ThreadArgs args1, args2, args3;
    clock_t start_time, end_time;
    double total_time;
    
    start_time = clock();

    args1.a = 5;
    args1.b = 10;
    args2.a = 15;
    args2.b = 20;


    pthread_create(&thread1, NULL, add_ab_thread, (void*)&args1);
    pthread_create(&thread2, NULL, add_cd_thread, (void*)&args2);
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    
    printf("e = %d\n", args1.result);
    printf("f = %d\n", args2.result);
    args3.a = args1.result;
    args3.b = args2.result;

    pthread_create(&thread3, NULL, add_ef_thread, (void*)&args3);
    pthread_join(thread3, NULL);
    printf("Result = %d\n", args3.result);

    end_time = clock();
    total_time = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;
    printf("Total time consumed by the code in parallel using pthreads: %f seconds\n", total_time);

    return 0;
}
