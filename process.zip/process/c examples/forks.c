#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main() {
    int fd = shm_open("/my_shared_memory", O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
    if (fd == -1) {
        perror("shm_open failed");
        return 1;
    }

    if (ftruncate(fd, sizeof(int)) == -1) {
        perror("ftruncate failed");
        return 2;
    }

    int *shared_counter = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
                               MAP_SHARED, fd, 0);
    if (shared_counter == MAP_FAILED) {
        perror("mmap failed");
        return 3;
    }

    *shared_counter = 0;

    pid_t pid1 = fork();
    if (pid1 == -1) {
        perror("fork failed");
        return 4;
    }

    if (pid1 == 0) {
       
        for (int i = 0; i < 1000000; i++) {
            (*shared_counter)++;
        }
        return 0;
    }

    pid_t pid2 = fork();
    if (pid2 == -1) {
        perror("fork failed");
        return 5;
    }

    if (pid2 == 0) {
        for (int i = 0; i < 1000000; i++) {
            (*shared_counter)++;
        }
        return 0;
    }

    wait(NULL); 
    wait(NULL); 

    printf("The total value of counter: %d\n", *shared_counter);

    if (munmap(shared_counter, sizeof(int)) == -1) {
        perror("munmap failed");
        return 6;
    }
    if (close(fd) == -1) {
        perror("close failed");
        return 7;
    }
    if (shm_unlink("/my_shared_memory") == -1) {
        perror("shm_unlink failed");
        return 8;
    }

    return 0;
}
