#include<stdio.h>
#include<time.h>

int add_ab(int a, int b)
{
    return a + b;
}
int add_cd(int c,int d)
{
    return c + d;
}
int add_ef(int e, int f)
{
    return e + f;
}
int main()
{
    int a, b, c, d, e, f, result;
    clock_t start_time , end_time;
    double total_time; 
    start_time = clock();
    a = 5;
    b = 10;
    c = 15;
    d = 20;
    e = add_ab(a,b);
    printf("e = %d\n",e);
    f = add_cd(c,d);
    printf("f = %d\n",f);
    result = add_ef(e,f);
    printf("Result = %d\n",result);
    end_time = clock();
    total_time = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;
    printf("Total time consumed by the code in sequential in c: %f\n", total_time);
    return 0;
}