#include<stdio.h>
#include<pthread.h>

int x = 0;

void* increment(){
    int i;
    for(i = 0; i<= 1000000; i++){
        x++;
    }
}

int main(){
    pthread_t t1,t2;
    if(pthread_create(&t1, NULL, &increment, NULL) != 0){
        return 1;
    }
    if(pthread_create(&t2, NULL, &increment, NULL) != 0){
        return 2;
    }
    if(pthread_join(t1, NULL)){
        return 3;
    }
    if(pthread_join(t2, NULL)){
        return 4;
    }
    printf("The value of x: %d\n",x);
    return 0;
}