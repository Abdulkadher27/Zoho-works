import asyncio

async def simple_coroutine(name, delay):
    print(f"{name} started.")
    await asyncio.sleep(delay)  
    print(f"{name} finished after {delay} seconds.")
    return f"{name} result"

async def set_future_result(future):
    print("Setting future result...")
    await asyncio.sleep(2)
    future.set_result("Future result set!")

async def main():
    print("Running coroutines:")
    result_a = await simple_coroutine("Coroutine A", 2)
    print(f"Coroutine A result: {result_a}")

    print("\nRunning tasks:")
    task = asyncio.create_task(simple_coroutine("Task", 3))
    result_b = await task
    print(f"Task result: {result_b}")

    print("\nUsing Future:")
    future = asyncio.Future()
    asyncio.create_task(set_future_result(future))
    
    future_result = await future
    print(f"Future result: {future_result}")

asyncio.run(main())
