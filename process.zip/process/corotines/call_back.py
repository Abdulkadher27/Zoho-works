import asyncio

def call_back(result):
    print(f"The {result} is completed!")

async def tasks_func():
    print("Am in task coroutine!")
    await asyncio.sleep(1)
    return 'task'    

async def main():
    print("The main coroutine!")
    tasks = []
    for _ in range(3):
        task = asyncio.create_task(tasks_func())
        task.add_done_callback(call_back)
        tasks.append(task)
        
    await asyncio.gather(*tasks) 
    
asyncio.run(main())           