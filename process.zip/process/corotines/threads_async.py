import asyncio
import time

def print_hi():
    start_time = time.time()
    print("hi this is thread!")
    time.sleep(1)
    end_time = time.time()
    print("the taken in another thread: ",end_time - start_time)
async def main():
    start_time = time.time()
    await asyncio.gather(asyncio.to_thread(print_hi), asyncio.sleep(1))
    print("This is async function")
    end_time = time.time()
    print("Total time in async funciton: ", end_time - start_time)
    
asyncio.run(main())    