import asyncio

async def hello():
    await asyncio.sleep(3)
    print('yay!')
    

async def main():
    try:
        task = asyncio.create_task(hello())
        await asyncio.shield(task)
        await asyncio.wait_for(task, timeout= 1.0) #by uisng sheild we can turn off the timeout!!! 
    except TimeoutError:
        print('timeout!')

asyncio.run(main())
