from threading import Thread
import time
import os

def memory_measure(pid):
    with open(f"/proc/{pid}/status", "r") as file:
        for line in file:
            if line.startswith("VmRSS"):
                memory_kb = int(line.split()[1])
                return memory_kb
    
def task1():
    print("hii from task1")
    time.sleep(1)
    print("bye from task1")    
def task2():
    print("hii from task2")
    time.sleep(1)
    print("bye from task2")    
def tasks3():
    print("hii from task3")
    time.sleep(1)
    print("bye from task3")    
def main():
    main_process = os.getpid()
    current_space = memory_measure(main_process)
    start_time = time.time()
    t1 = Thread(target=task1)
    t2 = Thread(target=task2)
    t3 = Thread(target= tasks3)
    
    threads = [t1,t2,t3]
    for t in threads:
        t.start()
        
    for t in threads:
        t.join()
        
    end_time = time.time()       
    print(end_time - start_time) 
    
    memory = memory_measure(main_process)
    print(f"Memory consumed by all the threads {memory - current_space} in kb")
if __name__ == "__main__":
    main()