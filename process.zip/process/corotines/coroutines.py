import inspect

def function2(y):
    print_task_state(inspect.currentframe())
    y += 1
    return y

def function1(x):
    x = function2(x)
    print_task_state(inspect.currentframe())
    x += 1
    return x

def print_task_state(frame):
    print(f"Function Name: {frame.f_code.co_name}")
    print(f"Current Line: {frame.f_lineno}")
    print("Local Variables:", frame.f_locals)
    print("Global Variables:", frame.f_globals)
    print("--" * 20)

def main():
    a = 0
    value = function1(a)
    value += 1
    print_task_state(inspect.currentframe())
    print(value)

if __name__ == "__main__":
    main()
