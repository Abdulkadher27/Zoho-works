import asyncio

shared_variable = 0
async def task1():
    global shared_variable
    for _ in range(5):
        shared_variable += 1
        print(f'value of shared_variable in task1 is {shared_variable}')

async def task2():
    global shared_variable
    for _ in range(5):
        shared_variable += 1
        print(f"value of shared variable in task2 is {shared_variable}")

async def main():
    global shared_variable 
    await asyncio.gather(task1(), task2())
    
    await asyncio.sleep(3)
    
    print(f"Value of shared_variable in main: {shared_variable}")

asyncio.run(main())