import asyncio

async def print_hi():
    print("Hello!")
    await asyncio.sleep(2)
    print("Helloooo")
    
async def child_task():
    try:
        print("child task") 
        await asyncio.sleep(1.5)
        print("from child bye!!!!")
    except KeyboardInterrupt:
        raise    
async def print_bye():
    try:
        print("from parent Bye")
        task3 = asyncio.create_task(child_task())
        await asyncio.shield(task3)
        await asyncio.sleep(3)
        print("from parent Byeeeee")  
    except asyncio.CancelledError:
        print("Parent print task is terminated")
        raise     
async def main():
    try:
        async with asyncio.TaskGroup() as tg:
            task1 = tg.create_task(print_hi())
            task2 = tg.create_task(print_bye())
            await asyncio.sleep(1)
            task2.cancel()
    except asyncio.CancelledError:
        print("Some child process might have cancelled")  
          
asyncio.run(main())