import asyncio
import time
async def calculate_sqr(value,delay):
    await asyncio.sleep(delay)
    sqr_sum = 0
    for i in range(1,value + 1):
        sqr_sum += i*i
        print(sqr_sum)
        if i == 15:
            await asyncio.sleep(0)
    print("The square_cal function executes completely")        
async def print_value(delay):
    await asyncio.sleep(delay)
    print("The function print_value is executing before calculate_sqr!!")
    await asyncio.sleep(delay)
    print("The function execute after the calculate function!!!")
    
    
    
async def main():
    start_time = time.time()
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(calculate_sqr(30,0.5))
        task2 = tg.create_task(print_value(0.25))
    print("All the tasks are executed completely")    
    end_time = time.time()
    print("the total execution time is :",end_time - start_time)
    

asyncio.run(main())