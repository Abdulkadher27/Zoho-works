import asyncio

async def task_to_cancel():
    try:
        print("Task starting...")
        await asyncio.sleep(5)
        print("Task completed!")
    except asyncio.CancelledError:
        print("Task was cancelled!")
        raise

async def cancel_task():
    try:
        task = asyncio.create_task(task_to_cancel())
        await asyncio.sleep(1) 
        task.cancel()  
        await task
    except asyncio.CancelledError:
        print("This tasks is forcefully cancelled!")    
asyncio.run(cancel_task())
