import asyncio

async def future_task(future,value):
    print("The task will exexute when the future variable is awaited")
    await asyncio.sleep(1)
    future.set_result(value)
    
async def main():
    loop = asyncio.get_event_loop()
    print("In the main function")
    future = loop.create_future()
    loop.create_task(future_task(future,'hello world'))
    print("Waiting for the future to be set")
    result = await future
    print("the result:",result)
    
asyncio.run(main())    