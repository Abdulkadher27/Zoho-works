import asyncio
import time

async def task_example(name):
    print(f"Task {name} starting")
    await asyncio.sleep(1)
    print(f"Task {name} finished")

async def run_tasks():
    start_time = time.time()
    task1 = asyncio.create_task(task_example("A"))
    task2 = asyncio.create_task(task_example("B"))
    await task1
    await task2
    end_time = time.time()
    print("The total time taken : ",end_time - start_time)

asyncio.run(run_tasks())
