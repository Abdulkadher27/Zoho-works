import asyncio

async def tasks_error(n):
    try:
        print("task with error")
        await asyncio.sleep(n)
        print("Execution completes!")
    except KeyboardInterrupt:
        raise    
    except asyncio.CancelledError:
        raise
async def tasks_(n):
    try:
        print("some task starts to execute")
        await asyncio.sleep(n)
        print("Execution completes!")
    except asyncio.CancelledError:
        print("the task is cancelled")
async def main():
    done = []
    pending = []
    try:
        async with asyncio.TaskGroup() as tg:
            task1 = tg.create_task(tasks_(1),name= 'task_1')
            task2 = tg.create_task(tasks_error(2),name= 'task_2')
            task3 = tg.create_task(tasks_(3),name= 'task_3')
            task4 = tg.create_task(tasks_(4),name= 'task_4')
            
            tasks = [task1, task2, task3, task4]
            task1.cancel()
            #done, pending = await asyncio.wait(tasks,return_when= asyncio.FIRST_COMPLETED)
            #done, pending = await asyncio.wait(tasks, return_when= asyncio.ALL_COMPLETED)
            done, pending = await asyncio.wait(tasks, return_when= asyncio.FIRST_EXCEPTION)
            for d in done:
                print(d)
            for p in pending:
                print(p) 
    except asyncio.CancelledError:
        print("some tasks might get cancelled!!")     

asyncio.run(main())