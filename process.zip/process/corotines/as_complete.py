import asyncio

async def open_connection_1(host, port):
    print("Waiting for connection")
    await asyncio.sleep(1)
    return f"Connection to {host}:{port} established."

async def open_connection_2(host, port):
    print("Waiting for connection")
    await asyncio.sleep(0.5)
    return f"Connection to {host}:{port} established." 
async def main():
    ipv4_connect = asyncio.create_task(open_connection_1("127.0.0.1", 80))
    ipv6_connect = asyncio.create_task(open_connection_2("::1", 80))
    tasks = [ipv4_connect, ipv6_connect]
    
    for completed_task in asyncio.as_completed(tasks):
        result = await completed_task
        print(result)

asyncio.run(main())
