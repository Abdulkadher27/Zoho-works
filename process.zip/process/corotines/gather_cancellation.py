import asyncio

async def task1():
    try:
        print("Task1 started")
        await asyncio.sleep(1)
        print("Task1 completed")
    except asyncio.CancelledError:
        print("Task1 was cancelled")
        raise

async def task2():
    try:
        print("Task2 started")
        await asyncio.sleep(10)
        print("Task2 completed")
    except asyncio.CancelledError:
        print("Task2 was cancelled")
        raise

async def main():
    try:
        tasks = [task1(), task2()]
        gather_task = asyncio.gather(*tasks)
        await asyncio.sleep(2)
        gather_task.cancel()
        await gather_task
    except asyncio.CancelledError:
        print("Gather was cancelled")

asyncio.run(main())
