import asyncio
import time

async def quick_task():
    print("The quick task function starts executing")
    print("The quick task function completes its execution!")
    
async def slow_task():
    print("the slow task starts executing")
    await asyncio.sleep(0.5)
    print("The slow task completes its execution!")    

async def run_without_eager_function():
    print("The tasks in the normal function starts!")
    task1 = asyncio.create_task(quick_task())
    task2 = asyncio.create_task(slow_task())
    await task1
    await task2
    print('All the tasks in the normal function completes its execution!') 

async def run_with_eager_function():
    print("The tasks in the eager function starts!")
    loop = asyncio.get_event_loop()
    
    loop.set_task_factory(asyncio.eager_task_factory)
    task1 = asyncio.create_task(quick_task())
    task2 = asyncio.create_task(slow_task())
    await task1
    await task2
    print('All the tasks in the eager function completes its execution!')    
    
async def main():
    start_time_w = time.time()
    await run_with_eager_function()
    end_time_w = time.time()
    print("the time taken for the eager function to complete its execution:", end_time_w - start_time_w)
    
    start_time_wo = time.time()
    await run_without_eager_function()
    end_time_wo = time.time()
    print("The time taken for function without eager to complete the execution: ",end_time_wo - start_time_wo)

asyncio.run(main())