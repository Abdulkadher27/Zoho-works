import asyncio
import time

async def calculate_2():
    sums = 0
    for i in range(10000000,20000000):
        sums += i * i
        print(sums)
        if i == 2500000:
            await asyncio.sleep(0)
async def caculate():
    n = 10000000
    sums = 0
    for i in range(n):
        sums += i * i
        print(sums)
        if i == 5000000:
            await asyncio.sleep(0)
async def main():
    start_time = time.time()
    print("Hi")
    task1 = asyncio.create_task(caculate())
    task2 = asyncio.create_task(calculate_2())
    
    await asyncio.sleep(5)
    await task1
    await task2
    print("Bye")
    end_time = time.time()
    print(end_time - start_time)
asyncio.run(main())