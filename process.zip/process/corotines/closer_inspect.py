import asyncio
import inspect

async def task3():
    '''This is the task3 example'''
    y = 0
    for _ in range(1, 11):
        y += 1
        print(f"Task 3 - The value of y: {y}")
        if _ == 5:
            print_task_state(asyncio.current_task())  
            await asyncio.sleep(0)

async def task4():
    '''This is the task4 example'''
    y = 0
    for _ in range(1, 11):
        y += 1
        print(f"Task 4 - The value of y: {y}")
        if _ == 5:
            print_task_state(asyncio.current_task())  
            await asyncio.sleep(0)

async def task1():
    '''This is the task1 example'''
    x = 0
    task_3 = asyncio.create_task(task3(), name='Task-3')
    for _ in range(1, 11):
        x += 1
        print(f"Task 1 - The value of x: {x}")
        if _ == 5:
            print_task_state(asyncio.current_task())  
            await asyncio.sleep(0)
            await task_3

async def task2():
    '''This is the task2 example'''
    x = 0
    task_4 = asyncio.create_task(task4(), name='Task-4')
    for _ in range(1, 11):
        x += 1
        print(f"Task 2 - The value of x: {x}")
        if _ == 5:
            print_task_state(asyncio.current_task())  
            await asyncio.sleep(0)
            await task_4

def print_task_state(task):
    frame = task.get_stack(limit=1)[0]
    print(f"Task: {task.get_name()}")
    print(f"Current Line: {frame.f_lineno}")
    print("Local Variables:", frame.f_locals)
    print("--" * 20)

async def main():
    task_1 = asyncio.create_task(task1(), name="Task-1")
    task_2 = asyncio.create_task(task2(), name="Task-2")
    
    await task_1
    await task_2

asyncio.run(main())
