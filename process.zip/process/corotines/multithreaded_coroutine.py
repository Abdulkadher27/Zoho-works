import asyncio
from threading import Thread
import os
import requests
import time

async def download_image(url, file_name):
    print(f"Started downloading {file_name}")
    response = requests.get(url)
    with open(file_name, 'wb') as file:
        file.write(response.content)
    print(f"Finished downloading {file_name}.")

async def task1():
    dirctory = "Image_coroutines"
    os.makedirs(dirctory, exist_ok=True)
    urls_t1 = [
        "https://cdn.britannica.com/48/252748-050-C514EFDB/Virat-Kohli-India-celebrates-50th-century-Cricket-November-15-2023.jpg"]
    file_name = f"{dirctory}/image1.jpg"
    await download_image(urls_t1[0], file_name)

async def task2():
    dirctory = "Image_coroutines"
    os.makedirs(dirctory, exist_ok=True)
    urls_t2 = ["https://akm-img-a-in.tosshub.com/indiatoday/images/story/202411/virat-kohli-24240570-16x9_0.jpg?VersionId=IZcU_Qjn9MKEY7XZe5x06KrfqTQaf25l",]
    file_name = f"{dirctory}/image2.jpg"
    await download_image(urls_t2[0], file_name)

async def task3():
    dirctory = "Image_coroutines"
    os.makedirs(dirctory, exist_ok=True)
    urls_t3 = ["https://img.olympics.com/images/image/private/t_s_16_9_g_auto/t_s_w960/f_auto/primary/tbxb5qkbi90pvehqcdzz"]
    file_name = f"{dirctory}/image3.jpg"
    await download_image(urls_t3[0], file_name)

async def task4():
    dirctory = "Image_coroutines"
    os.makedirs(dirctory, exist_ok=True)
    urls_t4 = ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1EdaVAtRcpMSIvrK2qmO_9xaS4Ex5t7xuKA&s"]
    file_name = f"{dirctory}/image4.jpg"
    await download_image(urls_t4[0], file_name)

async def main_1():
    start_time = time.time()
    await asyncio.gather(task3(), task4())
    end_time = time.time()
    print("The time taken for thread 1 to complete! ",end_time - start_time)

async def main_2():
    start_time = time.time()
    await asyncio.gather(task1(), task2())
    end_time = time.time()
    print("The time taken thread 2 to complete! ", end_time - start_time)

def run_async_in_thread(target_coro):
    asyncio.run(target_coro)

def main():
    start_time = time.time()
    print("The different coroutines for different threads are created!")
    t1 = Thread(target=run_async_in_thread, args=(main_1(),))
    t2 = Thread(target=run_async_in_thread, args=(main_2(),))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("All the threads and coroutines are executed!")
    end_time = time.time()
    print("The time taken for complete the download!",end_time - start_time)

if __name__ == "__main__":
    main()
