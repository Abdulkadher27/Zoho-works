import asyncio
import time
import os

def memory_measure(pid):
    with open(f"/proc/{pid}/status", "r") as file:
        for line in file:
            if line.startswith("VmRSS"):
                memory_kb = int(line.split()[1])
                return memory_kb
    
async def tasks1():
    print("hii from task1")
    await asyncio.sleep(1)
    print("bye from task1")
async def tasks2():
    print("hii from task2")
    await asyncio.sleep(1)
    print("bye from task2")
async def tasks3():
    print("hii from task3")
    await asyncio.sleep(1)
    print("bye from task3")    
async def main():
    main_process = os.getpid()
    space = memory_measure(main_process)
    start_time = time.time()
    tasks = []
    async with asyncio.TaskGroup() as tg:
        task_1 = tg.create_task(tasks1())
        task_2 = tg.create_task(tasks2())
        task_3 = tg.create_task(tasks3())
    end_time = time.time()
    print(end_time - start_time)    
    end = memory_measure(main_process)
    print(f"Memory consumed by the asyncio tasks {end - space} in kb")

asyncio.run(main())
