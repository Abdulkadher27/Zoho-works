import asyncio

async def tasks_error(n):
    try:
        print("task with error")
        await asyncio.sleep(n)
        print("Execution completes!")
    except asyncio.CancelledError:
        print(f"task {n} was cancelled")
        raise
    except Exception as e:
        print(f"task {n} encountered an error: {e}")
        raise

async def tasks_(n):
    try:
        print(f"some task {n} starts to execute")
        await asyncio.sleep(n)
        print(f"Execution completes for task {n}!")
    except asyncio.CancelledError:
        print(f"task {n} was cancelled")

async def main():
    done = []
    pending = []
    try:
        async with asyncio.TaskGroup() as tg:
            task1 = tg.create_task(tasks_(1), name='task_1')
            task2 = tg.create_task(tasks_error(2), name='task_2')
            task3 = tg.create_task(tasks_(3), name='task_3')
            task4 = tg.create_task(tasks_(4), name='task_4')

            tasks = [task1, task2, task3, task4]
            task1.cancel()
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)

            print("\nDone tasks:")
            for d in done:
                print(d)

            print("\nPending tasks:")
            for p in pending:
                print(p)

    except asyncio.CancelledError:
        print("Some tasks might have been cancelled!")

asyncio.run(main())
