import asyncio

async def timeout_check():
    print("hi")
    await asyncio.sleep(2)
    print("bye")
    await asyncio.sleep(2)
    print("am back")
async def main():
    try:
        #async with asyncio.timeout_at(None) as timeout:#.timeout and .timeout_at both are same!!! but varies when the whole block is created 
        async with asyncio.timeout(None) as timeout:    
            task1 = asyncio.create_task(timeout_check())# to when it should be cancelled!
            when = asyncio.get_running_loop().time() + 2
            timeout.reschedule(when)
            await task1
    except TimeoutError:
        print("Task take too many time for execution!!!")    
    if timeout.expired():
        print("Ohh! you take to many time for a execution!!!")
asyncio.run(main())
    