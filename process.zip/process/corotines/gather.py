import asyncio

async def task1():
    print("task1 is executing")
    await asyncio.sleep(1)  
    try:
        a = int('abc')
    except ValueError as e:
        print(f"print {e} has occurs in task1")
    
async def task2():
    print("Task2 is executing")
    await asyncio.sleep(0.5)  
    try:
        print("Currenlty in task2!!!")
    except KeyboardInterrupt as e:
        print(f"the {e} is occurred!!!")
        raise    
async def main():
    try:
        tasks = [task1(), task2()]
        result1 = await asyncio.gather(*tasks)
        print(result1)
        #result2 = await asyncio.gather(*tasks, return_exceptions= True)
        #print(result2)
    except asyncio.CancelledError as e:
        print(f"{e} has occured here !!!!")    
    print("All tasks executed!!!")
asyncio.run(main())