import asyncio
import time

async def worker(name, delay):
    print(f"Worker {name} starting")
    await asyncio.sleep(delay)
    print(f"Worker {name} finished")

async def manage_tasks():
    start_time = time.time()
    async with asyncio.TaskGroup() as task_group:
        task1 = task_group.create_task(worker("A", 2))
        task2 = task_group.create_task(worker("B", 1))

    print("All tasks completed or cancelled")
    end_time = time.time()
    print("Time taken for the tasks to finise its execution: ", end_time - start_time)

asyncio.run(manage_tasks())
