import asyncio
import time

async def keyboard_interrupt_task(name, delay):
    try:
        print(f"{name} starting")
        await asyncio.sleep(delay)
        print(f"{name} finished")
    except KeyboardInterrupt:
        print(f"{name} was interrupted by KeyboardInterrupt")
        raise  
    
async def value_error_task(name, delay):
    try:
        a = int('abc') 
        print(a)
    except ValueError as e:
        print(f"{name} caught ValueError: {e}")
        return f"{name} handled the error"

async def normal_task(name, delay):
    print(f"{name} starting")
    await asyncio.sleep(delay)
    print(f"{name} finished successfully")

async def manage_tasks():
    start_time = time.time()
    try:
        async with asyncio.TaskGroup() as task_group:
            task1 = task_group.create_task(keyboard_interrupt_task("Task A", 2))
            task2 = task_group.create_task(value_error_task("Task B", 3))
            task3 = task_group.create_task(normal_task("Task C", 4))

            await asyncio.sleep(1)

        print("All tasks are either completed or cancelled")

    except asyncio.CancelledError:
        print("All process are terminated")
    
        end_time = time.time()
        print("Total time taken for the tasks:", end_time - start_time)    

asyncio.run(manage_tasks())
