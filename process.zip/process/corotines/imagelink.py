import requests
import asyncio
import os
import time

async def download_image(url,file_name):
    print(f"Started downloading {file_name}")
    response = requests.get(url)
    with open(file_name, 'wb') as file:
        file.write(response.content)
    print(f"Finished downloading {file_name}.")
    
async def main():
    start_tme = time.time()
    dirctory = "Image_coroutines"
    os.makedirs(dirctory, exist_ok=True)
    urls = [
        "https://cdn.britannica.com/48/252748-050-C514EFDB/Virat-Kohli-India-celebrates-50th-century-Cricket-November-15-2023.jpg",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1EdaVAtRcpMSIvrK2qmO_9xaS4Ex5t7xuKA&s",
        "https://akm-img-a-in.tosshub.com/indiatoday/images/story/202411/virat-kohli-24240570-16x9_0.jpg?VersionId=IZcU_Qjn9MKEY7XZe5x06KrfqTQaf25l",
        "https://img.olympics.com/images/image/private/t_s_16_9_g_auto/t_s_w960/f_auto/primary/tbxb5qkbi90pvehqcdzz",
        "https://i.ytimg.com/vi/6f4-0m0AgOA/maxresdefault.jpg"
    ]
    tasks = []
    async with asyncio.TaskGroup() as tg:
        for i, url in enumerate(urls,start= 1):
            file_name = f"{dirctory}/image{i}.jpg"
            task = tg.create_task(download_image(url,file_name))
    end_time = time.time()
    print("Total time taken: ",end_time - start_tme)
asyncio.run(main())



