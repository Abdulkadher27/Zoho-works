import asyncio

async def task1():
    print("hi from task1")
    return 45
async def main():
    print("hi")
    task_1 = asyncio.create_task(task1(), name= 'Task-1')
    
    await task_1
    print(task_1)
    
asyncio.run(main())    