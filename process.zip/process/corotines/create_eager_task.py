import asyncio
import time

def custom_task_constructor(loop, coro):
    task = loop.create_task(coro)
    return task

eager_task_factory = asyncio.create_eager_task_factory(custom_task_constructor)

loop = asyncio.get_event_loop()
loop.set_task_factory(eager_task_factory)

async def quick_task():
    print("Quick task starts")
    await asyncio.sleep(0)  
    print("Quick task ends")

async def slow_task():
    print("Slow task starts")
    await asyncio.sleep(2)  
    print("Slow task ends")

async def main():
    start_time = time.time()
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(quick_task())
        task2 = tg.create_task(slow_task())
    end_time = time.time()
    print(f"Time taken with eager task factory: {end_time - start_time} seconds")

    # Reset the task factory to default
    loop.set_task_factory(None)

    start_time = time.time()
    async with asyncio.TaskGroup() as tg:
        task1 = tg.create_task(quick_task())
        task2 = tg.create_task(slow_task())
    end_time = time.time()
    print(f"Time taken without eager task factory: {end_time - start_time} seconds")

asyncio.run(main())

