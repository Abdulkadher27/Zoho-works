from multiprocessing import Process, Value

def increment(shared_value):
    for _ in range(100000):
        shared_value.value += 1

def main():
    shared_value = Value('i', 0)  
    processes = []
    for i in range(2):
        p = Process(target=increment, args=(shared_value,))
        processes.append(p)
    for p in processes:
        p.start()
    for p in processes:
        p.join()
    print(f"The value after two processes: {shared_value.value}")

if __name__ == "__main__":
    main() 

'''from threading import Thread    

value = 0
def increment():
    global value
    for _ in range(1000000):
        value += 1
        
def main():
    global value
    threads = []
    for i in range(2):
        t = Thread(target= increment)
        threads.append(t)
    for t in threads:
        t.start()
    for t in threads:
        t.join()    
    print("The value after 2 threads", value)
    
if __name__ == "__main__":
    main()                        '''