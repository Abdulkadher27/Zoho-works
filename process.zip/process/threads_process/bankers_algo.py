def main():
    threads = 5
    maximum_available_resoruce = [10, 5, 7]
    maximum_resources = [
        [7, 5, 3],
        [3, 2, 2],
        [9, 0, 2],
        [2, 2, 2],
        [4, 3, 3]
    ]
    allocated_resources =[
        [0, 1, 0],
        [2, 0, 0],
        [3, 0, 2],
        [2, 1, 1],
        [0, 0, 2]
    ]
    need = [[maximum_resources[i][j] - allocated_resources[i][j] for j in range(len(maximum_available_resoruce))] for i in range(threads)]
    available_resource = [maximum_available_resoruce[i] - sum(allocated_resources[j][i] for j in range(threads)) for i in range(len(maximum_available_resoruce))]
                
if __name__ == "__main__":
    main()
