import requests
import os
import time
from multiprocessing import Process
from threading import Thread

def download_file(url, file_name):
    print(f"Started downloading {file_name}")
    response = requests.get(url)
    with open(file_name, 'wb') as file:
        file.write(response.content)
    print(f"Finished downloading {file_name}.")

def memory_consumption(pid):
    with open(f"/proc/{pid}/status", "r") as file:
        for line in file:
            if line.startswith("VmRSS"):
                memory_kb = int(line.split()[1])
                return memory_kb
def main():
    start_time_thread = time.time()
    main_process_id = os.getpid()
    main_memory_used = memory_consumption(main_process_id)
    print("Main process id: ",main_process_id)
    print(f"The memory consumed by the main() process is :{main_memory_used} in KB")
    urls = [
        "https://cdn.britannica.com/48/252748-050-C514EFDB/Virat-Kohli-India-celebrates-50th-century-Cricket-November-15-2023.jpg",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1EdaVAtRcpMSIvrK2qmO_9xaS4Ex5t7xuKA&s",
        "https://akm-img-a-in.tosshub.com/indiatoday/images/story/202411/virat-kohli-24240570-16x9_0.jpg?VersionId=IZcU_Qjn9MKEY7XZe5x06KrfqTQaf25l",
        "https://img.olympics.com/images/image/private/t_s_16_9_g_auto/t_s_w960/f_auto/primary/tbxb5qkbi90pvehqcdzz",
        "https://i.ytimg.com/vi/6f4-0m0AgOA/maxresdefault.jpg"
    ]
    
    directory_1 = "images_thread"
    os.makedirs(directory_1, exist_ok= True)
    threads = []
    for i, url in enumerate(urls, start=1):
        file_name = f"{directory_1}/image{i}.jpg"
        thread = Thread(target=download_file, args=(url, file_name))  
        threads.append(thread)
    for thread in threads:    
        thread.start()
    for thread in threads:    
        thread.join()
        
    end_time_thread = time.time()
    print("Total time taken for threading: ",end_time_thread - start_time_thread)
    main_memory_thread_used = memory_consumption(main_process_id)
    print(f"The memory consumed by the thread is :{main_memory_thread_used - main_memory_used} in KB")
    
    start_time_process = time.time()
    directory_2 = "image_process"
    os.makedirs(directory_2, exist_ok= True)
    processes = []
    for i,url in enumerate(urls,start=1):
        file_name = f"{directory_2}/image{i}.jpg"
        process = Process(target=download_file, args=(url, file_name))
        processes.append(process)
    process_memory_used = []    
    for process in processes:   
        process.start()
        process_memory_used.append(memory_consumption(process.pid))
    for process in processes:    
        process.join()  
        process.terminate()
        
    end_time_process = time.time()
    print("Total time taken for Processing: ", end_time_process - start_time_process)
    for p in process_memory_used:
        print(f"The memory consumed by the process is :{p} in KB")


if __name__ == "__main__":
    main()
