from concurrent.futures import ThreadPoolExecutor
import time
import requests
import os
import itertools 

def download_image(url, file_name, image_no):
    """Downloads an image and saves it with a unique name"""
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        filename = os.path.join(file_name, f"image_{image_no}.jpg")
        with open(filename, "wb") as file:
            for chunk in response.iter_content(1024):
                file.write(chunk)
        print(f"Downloaded: {filename}")
    else:
        print(f"Failed to download image {image_no}")

def main():
    start_time = time.time()
    
    directory = "Downloaded_Images"
    os.makedirs(directory, exist_ok=True)
    
    url = "https://cdn.britannica.com/48/252748-050-C514EFDB/Virat-Kohli-India-celebrates-50th-century-Cricket-November-15-2023.jpg"
    
    with ThreadPoolExecutor(max_workers=25) as exec:
        exec.map(download_image, itertools.repeat(url), itertools.repeat(directory), range(1, 101))

    end_time = time.time()
    
    print("Total time taken for downloading images:", end_time - start_time)
    
if __name__ == "__main__":
    main()
