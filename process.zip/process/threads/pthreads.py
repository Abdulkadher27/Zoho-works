import ctypes
import time

libpthread = ctypes.CDLL("libpthread.so.0") #ctype is a standard c library! cdll is used to access with the compiled c lib
libc = ctypes.CDLL("libc.so.6") #essential c lib like printf() scanf()

pthread_t = ctypes.c_ulong #it is type of the pthread id it sis often unsigned long in most of the systems
pthread_create = libpthread.pthread_create #creating a pthread!
pthread_create.argtypes = [                                        #int pthread_create(
    ctypes.POINTER(pthread_t),  # Thread ID                                              pthread_t *thread,
    ctypes.c_void_p,            # Thread attributes                                      const pthread_attr_t *attr, 
    ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p),  # Start routine                 void *(*start_routine)(void *),
    ctypes.c_void_p             # Argument                                               void *arg 
]                                                                                    # )
pthread_create.restype = ctypes.c_int

pthread_join = libpthread.pthread_join
pthread_join.argtypes = [pthread_t, ctypes.c_void_p]
pthread_join.restype = ctypes.c_int

class ThreadArgs(ctypes.Structure):
    _fields_ = [("interval", ctypes.c_double), ("index", ctypes.c_int)]

def led_blinking(arg):
    args = ctypes.cast(arg, ctypes.POINTER(ThreadArgs)).contents
    interval = args.interval
    i = args.index

    for _ in range(5):  # Limit to 5 iterations for testing
        print(f"PThread {i}: LED is ON")
        time.sleep(interval)
        print(f"PThread {i}: LED is OFF")

    return ctypes.c_void_p()  # Explicitly return the correct C type

# Convert Python function to C-compatible function pointer
PThreadFuncType = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p)
pthread_func = PThreadFuncType(led_blinking)

def main():
    interval = float(input("Enter the LED blinking interval (seconds): "))
    thread_ids = []
    thread_args = []

    for i in range(1, 4):
        print(f"Creating PThread {i}")
        thread_id = pthread_t()
        thread_ids.append(thread_id)

        args = ThreadArgs(interval, i)
        thread_args.append(args)

        ret = pthread_create(
            ctypes.byref(thread_id), None, pthread_func, ctypes.byref(args)
        )
        if ret != 0:
            print(f"Failed to create PThread {i}")
            return

    for i, thread_id in enumerate(thread_ids, start=1):
        print(f"Joining PThread {i}")
        pthread_join(thread_id, None)

    print("All pthreads are terminated.")

if __name__ == "__main__":
    main()
