from datetime import datetime 
from threading import Thread
results = {}
def add_ab(a,b):
    results['ab'] = a + b
def add_cd(c,d):
    results['cd'] = c + d
def add_ef():
    e = results['ab']
    f = results['cd']
    results['ef'] =  e + f
def main():
    start_time = datetime.now()
    a = 5 #int(input("Enter the value for a: "))
    b = 10 #int(input("Enter the value for b: "))
    e = Thread(target= add_ab, args=(a,b))
    c = 15 #int(input("Enter the value for c: "))
    d = 20 #int(input("Enter the value for d: "))
    f = Thread(target=add_cd, args=(c,d))
    e.start()
    f.start()
    e.join()
    f.join()
    print("e = ",results['ab'])
    print("f = ",results['cd']) 
    result = Thread(target=add_ef)
    result.start()
    result.join()
    print("Result = ",results['ef'])
    end_time = datetime.now()
    print("total time taken for execution in threads: ",end_time - start_time)
if __name__ == "__main__":
    main()