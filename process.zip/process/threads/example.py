class Variables:
    a: int = 0

def increment(var : Variables):
    print(id(var.a))
    var.a += 2
    print(id(var.a))
    print((var.a))
  
var = Variables()
print(var.a)
print(id(var.a))
increment(var)
print(id(var.a))
print(var.a)

'''def append_list(lst):
    print(id(lst))
    lst.append(5)
    print(id(lst))
    
lst = [1,2,3,4]
print(id(lst))
append_list(lst)
print(id(lst))
print(lst)'''
"""
def increment(a):
    print(id(a))
    a += 2
    print(a)
    print(id(a))
    
a = 5
print(id(a))
print(a)
increment(a)
print(id(a))
print(a)"""
