import time as t 
from threading import Thread

def led_blinking(val,i):
    print(f"Led of thread{i} id Blinking")
    t.sleep(val)
    print(f"Led of thread{i} in not Blinking")
def main():
    val = float(input("Enter the blinking interval: "))
    for i in range(1,4):
        thread = Thread(target= led_blinking, args= (val, i))
        thread.start()
        t.sleep(3)
        print(f"The thread{i} is terminated by itself")
    print("All thread are terminated")    

if __name__ == "__main__":
    main()