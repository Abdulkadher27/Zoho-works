import numpy as np
from threading import Thread

shared_array = np.zeros(10)

def increment():
    global shared_array
    for _ in range(1000):
        shared_array += 1

threads = []
for i in range(5):
    thread = Thread(target= increment)
    threads.append(thread)
    
for thread in threads:
    thread.start()

for thread in threads:
    thread.join()

print(shared_array) 
