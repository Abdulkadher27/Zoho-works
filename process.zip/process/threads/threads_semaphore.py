from threading import Thread, Event
import time

waits = 0
semaphores = 1
def wait():
    global waits
    while waits >= semaphores:
        pass
    waits += 1
    
def signal():
    global waits
    waits -= 1
    
def Led_Blinking(val,i,stop):
    print(f"The Thread{i} is created")
    while not stop.is_set():
        wait()
        print(f"Led of Thread{i} is blinking")
        time.sleep(val)  
        print(f"Led of Thread{i} is not blinking")
        signal()
        time.sleep(0.05)
    print(f"Thread{i} is now terminated")     
def main():
    val = float(input("Enter the time for Blinking: "))
    stop = Event()    
    threads = []
    for i in range(1,4):
        t = Thread(target=Led_Blinking, args=(val, i, stop))
        threads.append(t) 
    for i in threads:     
        i.start()
        time.sleep(3)
    stop.set()      
    
    for i in threads:
        i.join()  
    
    print("All threads are terminated!!!")
if __name__ == "__main__":
    main()     