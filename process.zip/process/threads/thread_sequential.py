from datetime import datetime 

def add_ab(a,b):
    return a + b

def add_cd(c,d):
    return c + d
def add_ef(e,f):
    return e + f

def main():
    start_time = datetime.now()
    a = 5 #int(input("Enter the value for a: "))
    b = 10
    e = add_ab(a,b)
    print("e = ",e)
    c = 15 #int(input("Enter the value for c: "))
    d = 20 #int(input("Enter the value for d: "))
    f = add_cd(c,d)
    print("f = ",f)
    result = add_ef(e,f)
    print("result = ",result)
    end_time = datetime.now()
    print("total time taken for execution in sequential : ",end_time - start_time)
if __name__ == "__main__":
    main()