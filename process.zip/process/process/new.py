import time
from multiprocessing import Process, Semaphore

s = Semaphore(1)
def wait():
    s.acquire()

def signal():
    s.release()
        
def led_blinking(val,i):
    wait()
    for _ in range(5):
        print(f"Process {i} is executing Led is ON")
        time.sleep(val)
        print(f"Process{i} is executing Led is OFF")
    signal()
    
def main():
    proceses = []
    val = float(input("Enter the Blinking seconds: "))
    for i in range(1,4):
        p = Process(target=led_blinking, args= (val,i))
        proceses.append(p)
    for p in proceses:
        p.start()
    for p in proceses:        
        p.join()
        print(f"Process{i}  terminated is completed!!!")
    print("All the Proccesses are Terminated")
if __name__ == "__main__":
    main()    