import time
from multiprocessing import Process

waits = 0
semaphores = 1
def wait():
    global waits
    while waits >= semaphores:
        pass
    waits += 1
    
def signal():
    global waits
    waits -= 1
    
    
def led_blinking(val, i):
    wait() 
    for _ in range(5):
        print(f"Process {i} is executing Led is ON")
        time.sleep(val)
        print(f"Process {i} is executing Led is OFF") 
    signal()  

def main():
    processes = []
    val = float(input("Enter the Blinking seconds: "))
    
    for i in range(1, 4):
        p = Process(target=led_blinking, args=(val, i))
        #print(p)
        processes.append(p)
    for p in processes:
        p.start()    

    try:
        for p in processes:
            p.join()  
            p.terminate()
            print(f"Process {p.pid} terminated.")

    except KeyboardInterrupt:
        print("Manual interrupt received, terminating processes...")
        for p in processes:
            p.terminate()
            p.join()

    print("All Processes Terminated")

if __name__ == "__main__":
    main()
