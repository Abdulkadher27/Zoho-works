import time
from multiprocessing import Process

def led_blinking(val,i):
    for _ in range(5):
        print(f"Process {i} is executing Led is ON")
        time.sleep(val)
        print(f"Process{i} is executing Led is OFF")

def main():
    proceses = []
    val = float(input("Enter the Blinking seconds: "))
    for i in range(1,4):
        p = Process(target=led_blinking, args= (val,i))
        p.start()
        proceses.append(p)
        p.join()
        print(f"Process{i}  terminated is completed!!!")
    print("All the Proccesses are Terminated")
if __name__ == "__main__":
    main()    