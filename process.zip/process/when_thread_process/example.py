class Variables:

    x : int
    y : float
    
    
def increment(x:Variables):
    x.x += 1
    
def main():
    var = Variables()
    var.x = 5
    var.y = 4.5
    print(var.x)
    print(var.y)
    increment(var)
    print(var.x)
    print(var.y)
    
if __name__ == '__main__':
    main()