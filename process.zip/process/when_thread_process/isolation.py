from multiprocessing import Process

def value_p1(x):
    for _ in range(5):
        x += 1
    print("The value of same variable 'x' in Process 1: ",x)    

def value_p2(x):
    for _ in range(10):
        x += 1        
    print("The value of same variable 'x' in Process 2: ",x)
    
def main():
    x = 0
    processes = []
    p1 = Process(target= value_p1,args= (x,))
    p2 = Process(target= value_p2,args= (x,))
    processes.append(p1)
    processes.append(p2)
    
    for p in processes:
        p.start()
    for p in processes:
        p.join()    
    print("The value of same variable 'x' in Main Process: ",x)
    

if __name__ == "__main__":
    main()