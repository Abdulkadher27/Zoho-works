from threading import Thread
import threading
from multiprocessing import Process, Manager
import time
import os

def calculate_sum_of_squares(start, end, result, index):
    total = 0
    for i in range(start, end):
        total += i * i
    result[index] = total
def get_current_cpu_core_p(pid):
    with open(f"/proc/{pid}/stat", "r") as file:
        data = file.read().split()
        core = data[38]  
    return core
def get_current_cpu_core(pid,tid):
    with open(f"/proc/{pid}/task/{tid}/stat", "r") as file:
        data = file.read().split()
        core = data[38]  
    return core
def main():
    start = 1
    end = 10000000  
    num_threads = 4  
    num_processes = 4  

    chunk_size = (end - start) // num_threads
    ranges_threads = [(start + i * chunk_size, start + (i + 1) * chunk_size) for i in range(num_threads)]
    ranges_threads[-1] = (ranges_threads[-1][0], end)  
    
    chunk_size_process = (end - start) // num_processes
    ranges_processes = [(start + i * chunk_size_process, start + (i + 1) * chunk_size_process) for i in range(num_processes)]
    ranges_processes[-1] = (ranges_processes[-1][0], end)  
    
    manager = Manager()
    result_threads = manager.list([0] * num_threads)
    result_processes = manager.list([0] * num_processes)

    threads = []
    start_time_t = time.time()
    main_pid = os.getpid()
    for i, (st, en) in enumerate(ranges_threads):
        t = Thread(target=calculate_sum_of_squares, args=(st, en, result_threads, i))
        threads.append(t)
    for t in threads:
        core = get_current_cpu_core(main_pid,threading.get_native_id())    
        print(core)
        t.start()  

    for t in threads:
        t.join()

    total_sum_t = sum(result_threads)
    end_time_t = time.time()

    print(f"Total sum of squares (using threads): {total_sum_t}")
    print(f"Time taken for threads: {end_time_t - start_time_t} seconds")

    processes = []
    start_time_p = time.time()
    for i, (st, en) in enumerate(ranges_processes):
        p = Process(target=calculate_sum_of_squares, args=(st, en, result_processes, i))
        processes.append(p)
    for p in processes:  
        p.start() 
        #print(p.pid) 
        core = get_current_cpu_core_p(p.pid)
        print(core)  

    for p in processes:
        p.join()

    total_sum_p = sum(result_processes)
    end_time_p = time.time()

    print(f"Total sum of squares (using processes): {total_sum_p}")
    print(f"Time taken for processes: {end_time_p - start_time_p} seconds")

if __name__ == "__main__":
    main()
