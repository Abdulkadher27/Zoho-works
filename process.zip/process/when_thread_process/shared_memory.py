from threading import Thread
from multiprocessing import Process, Value


def thread_inc(x):
    x += 1
def process_inc(y):
    y.value += 1   
def main():
    x = 0
    y = Value('i',0)
    thread = []
    for _ in range(4):
        t = Thread(target= thread_inc, args=(x,))
        thread.append(t)
    for t in thread:
        t.start()
    for t in thread:
        t.join()
    print("x =",x)   
    
    process = []
    for _ in range(4):
        p = Process(target= process_inc, args=(y,))
        process.append(p)
    for p in process:
        p.start()
    for p in process:
        p.join()
    print("y =",y.value)
    
if __name__ == "__main__":
    main() 