from threading import Thread
from multiprocessing import Process
import time
import os
import threading

def count_words_files(file_name):
    with open(file_name, 'r') as file:
        content = file.read()
        words = len(content.split())
        print(f"The length of the words in is {words}")
def get_current_cpu_core_p(pid):
    with open(f"/proc/{pid}/stat", "r") as file:
        data = file.read().split()
        core = data[38]  
    return core
def get_current_cpu_core(pid,tid):
    with open(f"/proc/{pid}/task/{tid}/stat", "r") as file:
        data = file.read().split()
        core = data[38]  
    return core
def main():
    main_pid = os.getpid()
    files = ['/home/abdul-pt7764/ZohoWorkDrive/zoho_works/process/process_threads_creation/when_thread_process/file1.txt', 
             '/home/abdul-pt7764/ZohoWorkDrive/zoho_works/process/process_threads_creation/when_thread_process/file1.txt',
             '/home/abdul-pt7764/ZohoWorkDrive/zoho_works/process/process_threads_creation/when_thread_process/file3.txt']
    start_time_t = time.time()
    threads = []
    for file in files:
        t = Thread(target=count_words_files, args=(file,))
        threads.append(t)
    for t in threads:
        core = get_current_cpu_core(main_pid,threading.get_native_id())    
        print(core)
        t.start()
    for t in threads:
        t.join()
    end_time_t = time.time()
    total_time_t = end_time_t - start_time_t    
    print("Time taken for all the threads to read the files is: ",total_time_t)
    
    start_time_p = time.time()
    processes = []
    for files in files:
        p = Process(target= count_words_files, args=(files,))
        processes.append(p)
    for p in processes:
        p.start()
        core = get_current_cpu_core_p(p.pid)
        print(core) 
        
    for p in processes:
        p.join()
    end_time_p = time.time()
    total_time_p = end_time_p - start_time_p
    print("The time taken for all the processes to read the file is :",total_time_p)
    
if __name__ == "__main__":
    main()        