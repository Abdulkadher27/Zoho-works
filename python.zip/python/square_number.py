def sqr_method(x):
    return x * x

def cude_method(x):
    return x ** 3
    
def main():
    square = []
    cube = []
    i = 1
    while i <= 5:  
        square.append(sqr_method(i))
        cube.append(cude_method(i))
        i += 0.5
    print(square)
    print(cube)
    
if __name__ == "__main__":
    main()
