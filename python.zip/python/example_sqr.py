from square_number import sqr_method

n = int(input())
print(sqr_method(n))