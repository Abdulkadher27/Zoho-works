import csv
import random
import datetime
import os

class Library:
    '''Information about the Library!'''
    csv_file2 = 'borrow_return_csv.csv'
    
    def __init__(self):
        self.books = [
            Books("The Great Gatsby", 10.99, "F. Scott Fitzgerald", "1st Edition"),
            Books("1984", 12.50, "George Orwell", "2nd Edition"),
            Books("To Kill a Mockingbird", 14.00, "Harper Lee", "50th Anniversary Edition"),
            Books("The Catcher in the Rye", 9.99, "J.D. Salinger", "1st Edition"),
            Books("Pride and Prejudice", 7.99, "Jane Austen", "200th Anniversary Edition"),
            Books("The Hobbit", 11.50, "J.R.R. Tolkien", "3rd Edition"),
            Books("Moby Dick", 15.00, "Herman Melville", "1st Edition"),
            Books("War and Peace", 18.00, "Leo Tolstoy", "4th Edition"),
            Books("Brave New World", 13.00, "Aldous Huxley", "2nd Edition"),
            Books("The Odyssey", 8.99, "Homer", "1st Edition")
        ]
        self.borrowed_books = {}
        
    def display_books(self):
        '''Display the available books in the library '''
        print("The List of available Books in our library!")
        print("---" * 20)
        for i, book in enumerate(self.books,start= 1):
            print(f"{i}) {book}")
        print("---" * 20)
    
    def borrow_books(self,user):
        '''information about books bought!'''
        self.display_books()
        amount = 0
        ordered_books = []
        while True: 
            choice = int(input("Enter your choice ( 1 - 10): ")) - 1
            ordered_books.append(choice)
            print("---" * 20)
            print(self.books[choice].get_details())
            amount += self.books[choice].cal_totalamount()
            print("---" * 20)
            cont = int(input("Do you want to Continue buying Yes(1) or No(0): "))
            if cont == 0: 
                break
        self.borrowed_books[user.name] = ordered_books
        Library.borrow_csv({user.name: user}, self.borrowed_books,self.books)
        print("---" * 20)
        print("You have ordered!")
        for i,book in enumerate(ordered_books,start= 1):
            print(f"{i}) {self.books[book].order_books()}")
        print(f"Total amount to be paid: ${amount:.2f}")
        print("---" * 20)
       
    def return_books(self, lib_id):
        user_found = False
        borrowed_books = []
        updated_rows = []
        
        with open(self.csv_file2, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["Library ID"] == lib_id and row["Return Date"] == "":
                    borrowed_books.append(row["Book Name"])
                    row["Return Date"] = datetime.datetime.now().strftime("%d-%m-%Y")
                    user_found = True
                updated_rows.append(row) 
        
        if user_found:
            with open(self.csv_file2, mode='w', newline='') as file:
                fieldnames = ["Library ID", "Book Name", "Borrow Date", "Return Date"]
                writer = csv.DictWriter(file, fieldnames=fieldnames)

                writer.writerows(updated_rows)
                
            print(f"Thank you for using our books!")
            print("The returned books are!")
            print("---" * 20)
            for i,book in enumerate(borrowed_books,start=1):
                print(f"{i}) {book}")
                
    @classmethod 
    def borrow_csv(cls, users, borrowed_books, books):
        '''Saving users' information into the CSV file'''
        file_exists = os.path.exists(cls.csv_file2)
        with open(cls.csv_file2, mode='a', newline='') as file:
            fieldnames = ["Library ID", "Book Name", "Borrow Date", "Return Date"]
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            
            if not file_exists or os.stat(cls.csv_file2).st_size == 0:
                writer.writeheader()
            
            for user_name, book_indices in borrowed_books.items():
                library_id = users[user_name].library_id
                borrow_date = datetime.datetime.now().strftime("%d-%m-%y")
                return_date = ""  
                
                for book_index in book_indices:
                    book_name = books[book_index].name
                    writer.writerow({
                        "Library ID": library_id,
                        "Book Name": book_name,  
                        "Borrow Date": borrow_date,
                        "Return Date": return_date
                    })

                
            
class Books:
    """ This Class is for having the information about the Books"""
    def __init__(self, name, price, auther, version):
        self.name = name
        self.price = price
        self.auther = auther
        self.version = version
    
    def __str__(self):
        '''Returns the Book when the object is called'''
        return self.name
    
    def get_details(self):
        """Return the choosed Book information"""
        return f"Name of the Book = {self.name}\nPrice of that Book = ${self.price}\nAuthor of the Book = {self.auther}\nEdition of the Book = {self.version}"
    
    def order_books(self):
        '''Return the Bppks that are ordered by the customers!'''
        return f"Name of the Book = {self.name}"
    
    def cal_totalamount(self):
        '''This method is used to calculate the total amount for the books to be paid to buy books'''
        return self.price

class Users:
    ''' This Class is to set and get the information about the users'''
    user_csv = 'user_csv.csv' #clas level csv file
    def __init__(self):
        self._name = ''
        self._phone_no = None
        self._address = ''
        self._lid = ''
    
    @property    
    def name(self):
        ''' Get the name of the user'''
        return self._name
    
    @name.setter
    def name(self,name):
        ''' Set the name of the user'''
        self._name = name
       
    @property
    def phone_no(self):
        ''' Get the Phone Number of the user''' 
        return self._phone_no
         
    @phone_no.setter
    def phone_no(self,phone_no):
        ''' set the Phone Number of the user'''   
        self._phone_no = phone_no  
       
    @property
    def address(self):
        ''' Get the Address of the user''' 
        return self._address
    
    @address.setter
    def address(self,address):
        ''' Set the Address of the user''' 
        self._address = address     
    
    @property
    def email(self):
        ''' Get the Email of the user'''     
        return self._email
     
    @email.setter
    def email(self,email):
        ''' Set the Email of the user'''    
        self._email = email 
         
    @property
    def library_id(self):
        '''Getter for the Library ID'''
        return self._lid
    
    @library_id.setter
    def library_id(self,id):
        '''Setter for the Library Id'''
        self._lid = id
             
    @classmethod
    def save_user_csv(cls,users):
        '''saving users information into the csv file'''
        file_exists = os.path.exists(cls.user_csv)
        with open(cls.user_csv, mode= 'a',newline='') as file:
            fieldnames = ["Library ID","name", "phone_no", "address", "email"]
            writer = csv.DictWriter(file,fieldnames=fieldnames)
            
            if not file_exists or os.stat(cls.user_csv).st_size == 0:
                writer.writeheader()
            
            for user in users:
                writer.writerow(user)    
        
def main():
    library = Library()
    users = []
    print("Hello reader!!!")
    choice = int(input("1. Borrow a book!\n2. Return a book!\nEnter the choice! "))
    print(help(Users))
    print(help(Books))
    print(help(Library))
    print(help(main()))
    match choice:
        case 1:
            print("📚 Welcome to the Library!")
            print("Feel free to browse the collection and borrow a book of your choice.")
            print("Don't forget to return it on time so others can enjoy it too!")
            print()
            print("---" * 20)
            print("Enter the Information about you!")
            user_id = Users()
            user_id.library_id = random_id()
            name = input("Enter your Name: ")
            user_id.name = name
            phone_no = int(input("Enter the Phone number: "))
            user_id.phone_no = phone_no
            address = input("Enter your Address: ")
            user_id.address = address
            email = input("Enter your Email Address: ")
            user_id.email = email
            users.append({
                "Library ID": user_id.library_id,
                "name": user_id.name,
                "phone_no": user_id.phone_no,
                "address": user_id.address,
                "email": user_id.email
            })
            user_id.save_user_csv(users)
            print("---" * 20)
            print()
            print(f"Thank you {user_id.name} for choosing our library!!!")
            print(f"This is your Library ID {user_id.library_id} please take note of it")
            print()
            library.borrow_books(user_id)
              
        case 2:
            print("---" * 20)
            lib_id = input("Enter your Library ID to return books: ")
            library.return_books(lib_id)
            print("📖 Thank you for returning the book!")
            print("We hope you enjoyed reading it. Come back anytime to borrow more!")
            
def random_id():
    random_no = random.randint(1,99999)
    return f'LIB{random_no:05}' 


if __name__ == '__main__':
    main()