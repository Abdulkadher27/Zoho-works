import streamlit as st
def main():
    st.markdown("""
            <div style='text-align: center;'> 
            <h1>Swigy</h1>
            </div>
        """,unsafe_allow_html=True)
    st.html("<style>[data-testid='stHeaderActionElements'] </style>")

    st.image("https://images.moneycontrol.com/static-mcnews/2018/02/Swiggy.jpg?impolicy=website&width=1600&height=900",use_container_width=True)
    st.markdown("""
                <div style = 'text-align: center;'>
                <h3>How can I help you Today!!!</h3>
                """,unsafe_allow_html=True)
    st.html("<style>[data-testid='stHeaderActionElements'] </style>")

    st.write("Craving something sweet? Hit that Order button to browse our wide selection of desserts")
    if st.button("Click to the next page"):
        st.switch_page("./pages/customer.py")
    
if __name__ == '__main__':
    main()    
